import os
import joblib
import pandas as pd

from sklearn.metrics import classification_report, roc_auc_score
from sklearn.model_selection import train_test_split

model = joblib.load("best_model.pkl")
scaler = joblib.load("scaler.pkl")


def leader_board_predict_fn(X):
    X_scaled = scaler.transform(X)
    y_prob = model.predict_proba(X_scaled)[:, 1]
    return y_prob


path = "/data/mlproject22" if os.path.exists("/data/mlproject22") else "."
df = pd.read_csv(os.path.join(path, "transactions.csv.zip"))

X = df.drop("Class", axis=1)
y = df["Class"]

_, X_test, _, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

y_prob = leader_board_predict_fn(X_test)
y_pred = (y_prob >= 0.5).astype(int)

print("ROC-AUC:", roc_auc_score(y_test, y_prob))
print(classification_report(y_test, y_pred))
