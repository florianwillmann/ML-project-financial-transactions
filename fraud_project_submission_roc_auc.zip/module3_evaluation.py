"""Evaluate the fraud model."""

import torch
from sklearn.metrics import (
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


def evaluate(model, X, y, threshold=0.5, print_results=True):
    model.eval()
    with torch.no_grad():
        logits = model(torch.as_tensor(X, dtype=torch.float32))
        scores = torch.sigmoid(logits).flatten().cpu().numpy()

    predictions = (scores >= threshold).astype(int)
    metrics = {
        "precision": precision_score(y, predictions, zero_division=0),
        "recall": recall_score(y, predictions, zero_division=0),
        "f1": f1_score(y, predictions, zero_division=0),
        "roc_auc": roc_auc_score(y, scores),
        "pr_auc": average_precision_score(y, scores),
        "confusion_matrix": confusion_matrix(y, predictions).tolist(),
    }

    if print_results:
        for name, value in metrics.items():
            print(f"{name}: {value}")
    return scores, metrics
