"""Load the saved checkpoint and evaluate it without retraining."""

import pandas as pd
import torch
from sklearn.model_selection import train_test_split

from minimal_neural_network import Network
from module3_evaluation import evaluate
from run_fraud_project import MODEL_FILE, find_data_file


def main():
    saved = torch.load(MODEL_FILE, map_location="cpu", weights_only=False)
    model = Network(saved["input_size"], tuple(saved["hidden_sizes"]))
    model.load_state_dict(saved["model_state_dict"])

    frame = pd.read_csv(find_data_file())
    X = frame[saved["feature_columns"]]
    y = frame["Class"].to_numpy()
    _, X_test, _, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        stratify=y,
        random_state=42,
    )
    X_test = (
        (X_test.to_numpy() - saved["scaler_mean"]) / saved["scaler_scale"]
    ).astype("float32")

    _, metrics = evaluate(
        model,
        X_test,
        y_test,
        threshold=saved.get("threshold", 0.5),
        print_results=True,
    )
    print("Stored test ROC-AUC:", saved["test_metrics"]["roc_auc"])
    print("Recomputed test ROC-AUC:", metrics["roc_auc"])


if __name__ == "__main__":
    main()
