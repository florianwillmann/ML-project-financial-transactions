"""Small configurable neural network used by the fraud project."""

import torch
from torch import nn
from torch.nn import functional as F


class Network(nn.Module):
    def __init__(self, input_size, hidden_sizes):
        super().__init__()
        sizes = [input_size, *hidden_sizes, 1]
        self.layers = nn.ModuleList(
            nn.Linear(input_features, output_features)
            for input_features, output_features in zip(sizes, sizes[1:])
        )

    def forward(self, x):
        for layer in self.layers[:-1]:
            x = torch.sigmoid(layer(x))
        return self.layers[-1](x)


def train(
    X,
    y,
    hidden_sizes=(4,),
    epochs=25,
    learning_rate=0.01,
    pos_weight=100.0,
    seed=42,
):
    torch.manual_seed(seed)
    X_tensor = torch.as_tensor(X, dtype=torch.float32)
    y_tensor = torch.as_tensor(y, dtype=torch.float32).reshape(-1, 1)

    model = Network(X_tensor.shape[1], hidden_sizes)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    model.train()
    for _ in range(epochs):
        logits = model(X_tensor)
        loss = F.binary_cross_entropy_with_logits(
            logits,
            y_tensor,
            pos_weight=logits.new_tensor([pos_weight]),
        )
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    return model
