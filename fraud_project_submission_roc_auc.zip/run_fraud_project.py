"""Select a model on validation data, train it, and save the checkpoint."""

import os
from pathlib import Path

import torch

from minimal_neural_network import train
from module1_data import load_data
from module3_evaluation import evaluate


PROJECT_DIR = Path(__file__).resolve().parent
MODEL_FILE = PROJECT_DIR / "models" / "best_validation_model.pt"

CONFIGS = [
    {"hidden_sizes": (), "epochs": 50, "learning_rate": 0.01, "pos_weight": 100},
    {"hidden_sizes": (16,), "epochs": 25, "learning_rate": 0.01, "pos_weight": 100},
    {"hidden_sizes": (32, 16), "epochs": 25, "learning_rate": 0.01, "pos_weight": 100},
    {"hidden_sizes": (64, 32), "epochs": 25, "learning_rate": 0.01, "pos_weight": 100},
    {"hidden_sizes": (96, 48), "epochs": 25, "learning_rate": 0.01, "pos_weight": 100},
    {"hidden_sizes": (32, 16), "epochs": 50, "learning_rate": 0.005, "pos_weight": 160},
    {"hidden_sizes": (64, 32), "epochs": 50, "learning_rate": 0.005, "pos_weight": 160},
    {"hidden_sizes": (128, 64, 32), "epochs": 50, "learning_rate": 0.005, "pos_weight": 160},
]


def find_data_file():
    candidates = [
        Path(os.environ["FRAUD_DATA_FILE"]) if "FRAUD_DATA_FILE" in os.environ else None,
        Path("/data/mlproject22/transactions.csv.zip"),
        PROJECT_DIR / "transactions.zip",
        PROJECT_DIR.parent / "transactions.zip",
    ]
    for candidate in candidates:
        if candidate is not None and candidate.exists():
            return candidate
    raise FileNotFoundError(
        "Dataset not found. On JupyterHub it must be available at "
        "/data/mlproject22/transactions.csv.zip."
    )


def main():
    data_file = find_data_file()
    data = load_data(data_file)
    best_config = None
    best_metrics = None

    for config in CONFIGS:
        candidate = train(data["X_subtrain"], data["y_subtrain"], **config)
        _, metrics = evaluate(
            candidate,
            data["X_validation"],
            data["y_validation"],
            print_results=False,
        )
        print(
            f"{config} -> validation ROC-AUC={metrics['roc_auc']:.4f}, "
            f"PR-AUC={metrics['pr_auc']:.4f}"
        )
        if best_metrics is None or metrics["roc_auc"] > best_metrics["roc_auc"]:
            best_config = config
            best_metrics = metrics

    print("\nSelected configuration:", best_config)
    print("Validation metrics:", best_metrics)

    final_model = train(data["X_train"], data["y_train"], **best_config)
    _, test_metrics = evaluate(
        final_model,
        data["X_test"],
        data["y_test"],
        print_results=False,
    )

    artifact = {
        "model_state_dict": final_model.state_dict(),
        "input_size": data["X_train"].shape[1],
        "hidden_sizes": best_config["hidden_sizes"],
        "training_config": best_config,
        "feature_columns": data["feature_columns"],
        "scaler_mean": data["scaler"].mean_,
        "scaler_scale": data["scaler"].scale_,
        "threshold": 0.5,
        "validation_metrics": best_metrics,
        "test_metrics": test_metrics,
    }
    MODEL_FILE.parent.mkdir(parents=True, exist_ok=True)
    torch.save(artifact, MODEL_FILE)

    print("Test metrics:", test_metrics)
    print("Saved model:", MODEL_FILE)


if __name__ == "__main__":
    main()
