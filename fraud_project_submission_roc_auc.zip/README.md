# Fraud Detection Submission

This ZIP contains the non-L2 sigmoid neural network used by the Sunday
JupyterHub training notebook. Model selection maximizes validation ROC-AUC.

## Files

- `run_fraud_project.py`: training, model selection, final evaluation, and checkpoint saving
- `evaluate_saved_model.py`: checkpoint loading and evaluation without retraining
- `minimal_neural_network.py`: PyTorch model and training function
- `module1_data.py`: stratified data splits and standardization
- `module3_evaluation.py`: evaluation metrics
- `models/best_validation_model.pt`: trained model and preprocessing metadata
- `requirements.txt`: Python dependencies

The dataset is intentionally not included, as required by the project
instructions. On JupyterHub, the scripts automatically use
`/data/mlproject22/transactions.csv.zip`. For local execution, place
`transactions.zip` beside this folder or set `FRAUD_DATA_FILE` to its path.

## Commands

```bash
python run_fraud_project.py
python evaluate_saved_model.py
```

The official test notebook must be submitted separately under its original
filename. It should load `models/best_validation_model.pt` and must not train
the model.
